
README - How to upload this site to GitHub Pages
1) Create a repository named exactly: <your-username>.github.io
2) Upload the files from this ZIP root into the repository (index.html at repo root).
3) Commit and push. GitHub Pages will publish the site at:
   https://<your-username>.github.io
4) If you want to use a custom domain, add a file named CNAME with your domain.
5) To update the site, modify the files locally, re-upload or push the changes, then commit.

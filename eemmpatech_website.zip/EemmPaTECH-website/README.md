# EemmPaTECH empire — Website (GitHub Pages)

This is a simple multi-page static website prepared for the EemmPaTECH empire GitHub Pages repository.

## Contents
- `index.html` — Homepage
- `services.html` — Services listing
- `portfolio.html` — Placeholder portfolio
- `contact.html` — Contact page
- `css/style.css` — Stylesheet
- `assets/` — folder for images (empty)

## Deploy to GitHub Pages
1. Create a repository named `EemmPaTECH-empire.github.io` (case-insensitive).
2. Push these files to the repository root.
3. Go to the repository Settings → Pages and ensure the source is set to the `main` branch (or `gh-pages`) and root folder.
4. After a minute or two, your site will be available at `https://EemmPaTECH-empire.github.io/`.

## Customization
- Replace placeholders in `/assets/` with real images.
- Edit text and colors in `css/style.css`.
- Update contact emails in `contact.html` or footer.
